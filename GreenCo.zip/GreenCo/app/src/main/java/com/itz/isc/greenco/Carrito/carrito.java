package com.itz.isc.greenco.Carrito;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.itz.isc.greenco.R;

public class carrito extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);
    }
}