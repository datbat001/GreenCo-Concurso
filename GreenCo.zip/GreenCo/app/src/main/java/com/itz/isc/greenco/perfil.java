package com.itz.isc.greenco;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class perfil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
    }
}